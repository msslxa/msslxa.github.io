newPackage(
   "Identifiability", Version => "0.4", Date => "October 13, 2017",
    Authors => {{Name => "A. Massarenti", Email=> "alexmassarenti@id.uff.br"}, 
                {Name => "M. Mella", Email=> "mll@unife.it"},
                {Name => "G. Stagliano'", Email => "giovannistagliano@gmail.com"}},
    Headline => "Effective identifiability criteria for mixed symmetric tensors and polynomials",
    DebuggingMode => false, Reload => true)

export{"certifyIdentifiability","switchNotation","multirandom","multirandom'","findDecomposition"};

certifyIdentifiability = method(TypicalValue => Boolean);
switchNotation = method();
multirandom = method(TypicalValue => RingElement); 
multirandom' = method(TypicalValue => Matrix); 
findDecomposition = method(TypicalValue => RingElement);

-----------------------------------------------------------------
------------------------- Main method ---------------------------
-----------------------------------------------------------------

certifyIdentifiability (RingElement,List,List,ZZ) := (F,l,a,h) -> ( -- undocumented
   checkRing F; checkSize l; checkRank h; d:=checkHomogeinity'(F,l); 
   if (#l==1) then if (h==WaringRank(l_0-1,d_0) and h>1) then if ((l_0==2 and odd d_0) or (l_0==4 and d_0==3) or (l_0==3 and d_0==5)) then (<<"-- applying Theorem 3.8 ("<<h<<"-identifiability for "<<l_0<<"-forms of degree "<<d_0<<")..."<<endl; return identifiabilityCriterion F);
   checkFlattening(a,l,d); checkInequality(l,a,h,false); b:=apply(#l,i->d_i-a_i); 
   v:=SegreVeronese(ring F,l,b);
   H:=linearSpanOfRows(apolarityMatrix(F,l,a,b),source v);
   if dim H =!= h then (checkEffectivity(l,d,a,b,h,false); return false);
   X:=trim(H + kernel v);
   if (dim X == 1) and (degree X == h) then (print("-- specific "|toString(h)|"-identifiability certified"); return true) else (checkEffectivity(l,d,a,b,h,false); return false);
);

certifyIdentifiability (RingElement,List,ZZ) := (F,l,h) -> (
    checkRing F; checkSize l; checkRank h;
    a:=first findFlattening(l,last Multidegree(F,l),h);
    return certifyIdentifiability(F,l,a,h);
);

certifyIdentifiability (RingElement,ZZ) := (F,h) -> (
   checkRing F; checkRank h;
   (l,d):=detectMaximalMultihomogeneity F;
   a:=first findFlattening(l,d,h);
   return certifyIdentifiability(F,l,a,h);
);

certifyIdentifiability (RingElement) := (F) -> ( -- undocumented
   checkRing F; 
   (l,d):=detectMaximalMultihomogeneity F;
   if (#l==1) and (WaringRank(l_0-1,d_0)>1) and ((l_0==2 and odd d_0) or (l_0==4 and d_0==3) or (l_0==3 and d_0==5)) then (
      <<"-- certifyIdentifiability expects an integer h>0 as second argument, but it was not passed; h will be taken to be "<<WaringRank(l_0-1,d_0)<<", the generic Waring rank for "<<l_0<<"-forms of degree "<<d_0<<endl;
      return identifiabilityCriterion F;
   ) else (
      <<"-- certifyIdentifiability expects an integer h>0 as second argument, but it was not passed; now it will be runned using several integers h until 'true' (or an error) appears."<<endl;
      cond:=false; 
      for h from 1 when not cond do (
              <<"h="<<toString(h)<<",  certifyIdentifiability(*,"<<toString(h)<<") --> ";
              cond=certifyIdentifiability(F,l,h);
              <<toString(cond)<<endl
       );
    );
);

certifyIdentifiability (Matrix,List,List) := (M,l,a) -> ( -- undocumented
   if numgens target M != 1 then error "expected a row matrix";
   h:=numgens source M; 
   M=flatten entries M; F:=sum M;
   checkRing F; checkSize l; d:=checkHomogeinity'(F,l); 
   if (#l==1) then if (h==WaringRank(l_0-1,d_0) and h>1) then if ((l_0==2 and odd d_0) or (l_0==4 and d_0==3) or (l_0==3 and d_0==5)) then (<<"-- applying Theorem 3.8 ("<<h<<"-identifiability for "<<l_0<<"-forms of degree "<<d_0<<")..."<<endl; return identifiabilityCriterion F);
   checkFlattening(a,l,d); checkInequality(l,a,h,false); 
   b:=apply(#l,i->d_i-a_i); 
   v:=SegreVeronese(ring F,l,b);
   H:=linearSpanOfRows(apolarityMatrix(F,l,a,b),source v);
   if dim H =!= h then (checkEffectivity(l,d,a,b,h,false); return false);
   SV:=trim kernel v; X:=H+SV;
   if (dim X != 1) then (checkEffectivity(l,d,a,b,h,false); return false);
   if degree X == h then (print("-- "|toString(h)|"-identifiability certified"); return true);
   if not (degree X <= h+1 and h+dimSV(l,b) == dimAmbientSV(l,b)+1) then (checkEffectivity(l,d,a,b,h,false); return false);
     <<"-- applying Proposition 3.3..."<<endl;
   v':=SegreVeronese(ring F,l,d);
   H':=linearSpanOfRows(matrix coeffs(M,l,d),source v');
   if degree(H'+kernel v') == h then (print("-- "|toString(h)|"-identifiability certified"); return true) else (checkEffectivity(l,d,a,b,h,false); return false); 
);

certifyIdentifiability (Matrix,List) := (F,l) -> (
    if numgens target F != 1 then error "expected a row matrix";
    checkRing F; checkSize l;
    h:=numgens source F;
    a:=first findFlattening(l,last Multidegree(first flatten entries F,l),h);
    return certifyIdentifiability(F,l,a);
);

certifyIdentifiability (Matrix) := (F) -> (
   if numgens target F != 1 then error "expected a row matrix";
   checkRing F; 
   h:=numgens source F;
   (l,d):=detectMaximalMultihomogeneity sum flatten entries F; -- first flatten entries F;
   a:=first findFlattening(l,d,h);
   return certifyIdentifiability(F,l,a);
);

identifiabilityCriterion = (F) -> (
   n:=numgens ring F -1; d:=first degree F;
   w:=WaringRank(n,d); r:=w+2*n^2-9*n+5;
      if not ((n==1 and odd d) or (n==3 and d==3) or (n==2 and d==5)) then error("expected a polynomial of odd degree in 2 variables, or of degree 5 in 3 variables, or of degree 3 in 3 variables, but got polynomial of degree "|toString(d)|" in "|toString(n+1)|" variables"); 
   M:=apolarityMatrix(F,{n+1},{r},{d-r});
   M':= matrix(SegreVeronese(ring F,{n+1},{d-r})) || M;
   if (rank M == numgens target M) and (codim minors(numgens target M',M') > n) then (print("-- "|toString(w)|"-identifiability certified"); return true) else (return false);  
);

-----------------------------------------------------------------
--------------------- Auxiliary functions -----------------------
-----------------------------------------------------------------

WaringRank = method(TypicalValue => ZZ);
WaringRank (ZZ,ZZ) := (n,d) -> (
   if d==2 then return n+1;
   if (d,n) == (4,2) then return 6;
   if (d,n) == (4,3) then return 10;
   if (d,n) == (3,4) then return 8;
   if (d,n) == (4,4) then return 15;
   return ceiling(binomial(n+d,d)/(n+1));
);

linearSpanOfRows = (M,R) -> (
    m:=numgens target M -1;
    u:=local u; x:=local x; K:=coefficientRing R; n:=numgens R -1;
    assert (numgens source M -1 == n and ring M === K);
    S:=K[u_0..u_m,x_0..x_n,MonomialOrder=>Eliminate(m+1)];
    I:=ideal(matrix{toList(u_0..u_m)} * M - matrix{toList(x_0..x_n)});
    trim sub(sub(ideal selectInSubring(1,gens gb I),K[x_0..x_n]),vars R)
);

Multigens = method(TypicalValue => List);
Multigens (PolynomialRing,List) := (R,l) -> ( -- l=(n1,n2,...np), R=K[x_1,...,x_n1,x_(n1+1),...,x_(n1+n2),...,x_(n1+n2+...+np)]
   x:=gens R; local s;
   assert(#x == sum l); 
   prepend(for j to l_0-1 list x_j,for i from 1 to #l-1 list (s=sum l_{0..(i-1)}; for j to l_i-1 list x_(s+j)))
);

Multidegree = method();
Multidegree (RingElement,List) := (F,l) -> (
  a:=local a; K:=coefficientRing ring F; n:=numgens ring F;
  R:=K[a_1..a_n]; 
  x:=Multigens(R,l);
  R':=K[x_0]; for i from 1 to #l-1 do R'=R'[x_i];
  F':=sub(sub(F,vars R),R');
  (isHomogeneous F',reverse degree F')
);

SegreVeronese = method(TypicalValue => RingMap);
SegreVeronese (PolynomialRing,List,List) := (R,l,d) -> ( -- l=(n1,...,np),d=(d1,...,dp)
   assert(#l==#d); 
   x:=Multigens(R,l);
   local mm; local c; K:=coefficientRing R;
   I:=flatten entries gens product for i to #l-1 list (
       mm=flatten entries gens (ideal x_i)^(d_i);
       c=flatten entries sub(last coefficients(matrix((sum x_i)^(d_i)),Monomials=>mm),K);
       ideal for j to #mm-1 list c_j*mm_j
   );
   z:=local z;
   map(R,K[z_0..z_(#I-1)],I)
);
dimAmbientSV = (l,d) -> -1+product for i to #l-1 list binomial(l_i-1+d_i,d_i); 
dimSV = (l,d) -> (sum l)-#l;
degreeSV = (l,d) -> (l=apply(l,u->u-1); sub((sum l)!/(product apply(l,u->u!)) * product apply(#l,i->(d_i)^(l_i)),ZZ));

apolarityMatrix = (F,l,a,b) -> ( 
      assert(#l==#a and #a==#b and checkHomogeinity'(F,l) == apply(#l,i->a_i+b_i));
  x:=Multigens(ring F,l);
  mma:=flatten entries gens product for i to #l-1 list (ideal x_i)^(a_i);
  mmb:=flatten entries gens product for i to #l-1 list (ideal x_i)^(b_i);
  D:=apply(mma,t->diff(t,F));
  transpose sub(last coefficients(matrix{D},Monomials=>mmb),coefficientRing ring F)
);

coeffs = method(TypicalValue=>List);
coeffs (RingElement,List,List) := (F,l,d) -> flatten entries apolarityMatrix(F,l,toList((#l):0),d);
coeffs (List,List,List) := (L,l,d) -> for i to #L-1 list coeffs(L_i,l,d);

findFlattening = (l,d,h) -> (
  assert(#l==#d);
  local a; local b;
  if #l==1 then (-- a=max{s : binom(n+s,n) >= h > binom(n+s-1,n)}
       n:=l_0-1; 
       a=last for s from (1+last for s from -1 when binomial(n+s,n)<h list s) when h>binomial(n+s-1,n) list s;
       if (a>=0 and a<=d_0) then return ({a},{d_0-a});
  );
  attempt:= () -> (a=apply(#l,i->random(0,d_i)); b=apply(#l,i->d_i-a_i););
  cond1:= () -> checkInequality(l,a,h,true);
  cond2:= () -> cond1() and checkEffectivity(l,d,a,b,h,true);
  (a,b)=(apply(#l,i->ceiling(d_i/2)),apply(#l,i->floor(d_i/2)));
  e:=0;
  while e<900 do (       
      if cond2() then return (a,b);
      attempt(); e=e+1
  );
  while e<1000 do (       
      if cond1() then return (a,b);
      attempt(); e=e+1
  );
  error "unable to find flattening in 1000 random attempts";
);

detectMaximalMultihomogeneity = (F) -> (  
  if not isHomogeneous F then error("trying to detect multihomogeneity of a non-homogeneous polynomial");
  recursionDetect := (F,l) -> (
     n:=numgens ring F; 
     m:=sum l;
     if m==n then return l;
     for i from 1 to n-m do if first Multidegree(F,l|{i,n-m-i}) then return recursionDetect(F,append(l,i));
  );
  l:=recursionDetect(F,{});
  d:=last Multidegree(F,l);
  if #l>1 then (
      print("-- got mixed symmetric tensor of dimensions "|toString(l)|" and multidegree "|toString(d)) 
  ) else ( 
      print("-- got symmetric tensor of dimension "|toString(first l)|" and degree "|toString(first d))
  );
  return (l,d);
);

-----------------------------------------------------------------
--------------------- Random tensors ----------------------------
-----------------------------------------------------------------

TENSORS:=local TENSORS;
tensorsRing = method(TypicalValue => PolynomialRing);
tensorsRing (List,Ring) := (l,KK) -> (
   ch:=char KK;
   if ( KK =!= QQ and KK =!= ZZ/ch ) then return KK[deepSplice for i to #l-1 list (vars i)_1..(vars i)_(l_i)];
   if (class TENSORS_(l,ch) === PolynomialRing) then return TENSORS_(l,ch); 
   TENSORS_(l,ch) = KK[deepSplice for i to #l-1 list (vars i)_1..(vars i)_(l_i)];
   return TENSORS_(l,ch)
);

multirandom' (List,List,ZZ,Ring) := (l,d,r,KK) -> ( 
   if #l=!=#d then error "the list of the degrees must have the same length as the list of the groups of variables";
   checkRank r; checkSize l;
   R:=tensorsRing(l,KK);
   checkRing (0_R);
   x:=Multigens(R,l);
   matrix{for i to r-1 list product for j to #l-1 list (sub(random(1,KK[x_j]),R))^(d_j)}
);
multirandom' (List,List,Ring) := (l,d,R) -> multirandom'(l,d,1+abs random ZZ,R);
multirandom' (List,List,ZZ) := (l,d,r) -> multirandom'(l,d,r,QQ);
multirandom' (List,List) := (l,d) -> multirandom'(l,d,QQ);

multirandom (List,List,ZZ,Ring) := (l,d,r,KK) -> sum flatten entries multirandom'(l,d,r,KK);
multirandom (List,List,ZZ) := (l,d,r) -> sum flatten entries multirandom'(l,d,r);
multirandom (List,List,Ring) := (l,d,R) -> (
   P:=flatten entries matrix SegreVeronese(ring multirandom(l,d,1,R),l,d);
   sum for j to #P-1 list random(R) * P_j 
);
multirandom (List,List) := (l,d) -> multirandom(l,d,QQ);

-----------------------------------------------------------------
---------------- Switch notation for tensors --------------------
-----------------------------------------------------------------

coeffs2 = method(TypicalValue=>Array);
coeffs2 (RingElement) := (F) -> ( 
  mm:=flatten entries gens (ideal gens ring F)^(first degree F);
  new Array from flatten entries transpose sub(last coefficients(matrix F,Monomials=>mm),coefficientRing ring F)
);
coeffs2 (Array) := (L) -> new Array from for i to #L-1 list coeffs2 L_i;

makeArray = method();
makeArray (RingElement,List,List) := (F,l,d) -> (
  a:=local a; K:=coefficientRing ring F; n:=numgens ring F;
  R:=K[a_1..a_n]; 
  x:=Multigens(R,l);
  R':=K[x_0]; for i from 1 to #l-1 do R'=R'[x_i];
  F':=sub(sub(F,vars R),R');
  C:=F'; for i to #l-1 do C=coeffs2 C; 
  new Array from C
);

makePol = method();
makePol (Array,List,List) := (L,x,d) -> (
  if class first L =!= Array then return ((gens (ideal last x)^(last d))*transpose(matrix{new List from L}))_(0,0);
  x':=for i to #x-2 list x_i; d':=for i to #d-2 list d_i;
  return makePol(new Array from for i to #L-1 list makePol(L_i,x',d'),x,d);
);

switchNotation (RingElement,List,List) := (F,l,d) -> (
  checkRing F; checkSize l; d':=checkHomogeinity'(F,l);
  if d' =!= d then error "the given multidegree is wrong (you may skip this argument)";
  (makeArray(F,l,d),l,d)
);
switchNotation (RingElement) := (F) -> (
  checkRing F;
  (l,d):=detectMaximalMultihomogeneity F;
  switchNotation(F,l,d)
);

switchNotation (Array,List,List) := (L,l,d) -> (
  if #l=!=#d then error "the list of the degrees must have the same length as the list of the groups of variables";
  checkSize l;
  K:=((a)->(while class a === Array do a=first a; ring a)) L;
  if K===ZZ then K=QQ;
  if not isField K then error "unable to find coefficient ring"; 
  R:=tensorsRing(l,K);
  x:=Multigens(R,l);
  (makePol(L,x,d),l,d)
);

-----------------------------------------------------------------
------- Naive methods for finding decompositions ----------------
-----------------------------------------------------------------

findDecomposition (RingElement,ZZ) := (F,h) -> (
    checkRing F; checkHomogeinity F; checkRank'(F,h);
    D:=entryLocusAffine(F,h);
    dimD:=dim D -1; degD:=degree D;
    if (dimD>0 or degD>h) then error ("the input polynomial is not "|toString(h)|"-identifiable");
    if not (dimD==0 and degD==h) then (<<"-- debug message: recomputing entry locus\n"; D=entryLocus(F,h); dimD=dim D -1; degD=degree D); 
    if not (dimD==0 and degD==h) then error ("the input polynomial is not "|toString(h)|"-identifiable");
    D':=dualScheme D;
    if not (numgens D' == 1 and degree D' == h) then error ("something went wrong");
    return D'_0;
);

findDecomposition (RingElement,ZZ,Nothing) := (F,h,nu) -> (
  n:=numgens ring F -1; d:=first degree F;
  <<"Input 1: homogeneous form F of degree "<<d<<" on P^"<<n<<endl;
  <<"Input 2: integer h="<<h<<endl;
  <<"Output: ideal of the h-entry locus with respect to F (thought as point of P^"<<binomial(n+d,d)-1<<") of the h-th higher secant variety, Sec_h(nu_"<<d<<"(P^"<<n<<")) subset P^"<<(binomial(n+d,d)-1)<<", of the "<<d<<"-th Veronese of P^"<<n<<endl;
  return entryLocus(F,h);
);

entryLocus = method(TypicalValue => Ideal);
entryLocus (RingElement,ZZ) := (F,h) -> (
  checkRing F; checkHomogeinity F; checkRank'(F,h);
  n:=numgens ring F -1; d:=first degree F; K:=coefficientRing ring F; 
  mm:=gens((ideal vars ring F)^d);
  a:=flatten entries sub(last coefficients(matrix F,Monomials=>mm),K);
  b:=flatten entries sub(last coefficients(matrix((sum gens ring F)^d),Monomials=>mm),K);
  x:=for i to #a -1 list (a_i)/(b_i);
  u:=local u; t:=local t;
  R:=K[u_0..u_(h-1),t_(0,0)..t_(h-1,n),MonomialOrder=>Eliminate((n+1)*(h-1)+h)];
  M:=matrix apply(h,j -> flatten entries gens (ideal(t_(j,0)..t_(j,n)))^d);
  J:=trim ideal(matrix{x} - matrix{toList(u_0..u_(h-1))} * M);     
  J=sub(ideal selectInSubring(1,gens gb J),K[t_(h-1,0)..t_(h-1,n)]);
  sub(J,vars ring F)
);

entryLocusAffine = method(TypicalValue => Ideal); -- "slightly probabilistic" but faster than entryLocus
entryLocusAffine (RingElement,ZZ) := (F,h) -> ( 
  n:=numgens ring F -1; d:=first degree F; K:=coefficientRing ring F; 
  mm:=gens((ideal vars ring F)^d);
  a:=flatten entries sub(last coefficients(matrix F,Monomials=>mm),K);
  b:=flatten entries sub(last coefficients(matrix((sum gens ring F)^d),Monomials=>mm),K);
  x:=for i to #a -1 list (a_i)/(b_i);
  u:=local u; t:=local t;
  R:=K[u_0..u_(h-1),t_(0,1)..t_(h-1,n),MonomialOrder=>Eliminate(n*(h-1)+h)];
  M:=matrix apply(h,j -> flatten entries gens (ideal(1,t_(j,1)..t_(j,n)))^d);
  J:=trim ideal(matrix{x} - matrix{toList(u_0..u_(h-1))} * M);     
  J=sub(ideal selectInSubring(1,gens gb J),K[t_(h-1,1)..t_(h-1,n)]);
  J=(map(ring F,ring J,submatrix(vars ring F,{1..n}))) J;
  homogenize(J,first gens ring J)
);

dualScheme = (I) -> ( -- only for when V(I) is smooth and ordinary
    z:=local z; n:=numgens ring I -1;
    R:=(coefficientRing ring I)[gens ring I,z_0..z_n,MonomialOrder=>Eliminate(n+1)];
    J:=sub(I,R) + minors(codim(I)+1,sub(jacobian I,R)|transpose(matrix{toList(z_0..z_n)})); 
    J=saturate(J,sub(ideal gens ring I,R));
    D:=ideal selectInSubring(1,gens gb(J,SubringLimit=>1));
    trim sub(sub(D,(coefficientRing ring I)[z_0..z_n]),vars ring I) 
);

-----------------------------------------------------------------
--------------------- Checkings on inputs -----------------------
-----------------------------------------------------------------

checkRing = (F) -> (
    if not isPolynomialRing ring F then error "the base ring must be a polynomial ring";
    if not isField coefficientRing ring F then error "the coefficient ring needs to be a field";
);
checkRank = (h)-> if h<=0 then error("the integer must be positive; it stands for the rank of the tensor");
checkRank' = (F,h)-> (
   if h<=0 then error("the integer must be positive");
   if h>WaringRank(numgens ring F -1,first degree F) then <<"-- the input integer exceeds the generic Waring rank"<<endl;
);
checkSize = (l)-> try (assert(#l>0); for i to #l-1 do assert(l_i>0 and class(l_i)===ZZ)) else error("expected a list of positive integers to indicate the dimensions of the mixed symmetric tensor, but got "|toString(l));
checkHomogeinity = (F) -> if not isHomogeneous F then error "the polynomial must be homogeneous";
checkHomogeinity' = (F,l) -> (
   (isHom,d):=Multidegree(F,l); if not isHom then error("expected a mixed symmetric tensor (multihomogeneous polynomial) of dimensions "|toString(l));
   return d;
);
checkFlattening = (a,l,d) -> (try (assert(#a===#l); for i to #a-1 do assert(a_i>=0 and a_i<=d_i and class(a_i)===ZZ)) else error "got bad list for flattening (you may skip this argument)";);
checkInequality = (l,a,h,quiet) -> (
    if dimAmbientSV(l,a)+1 >= h then return true; 
    if quiet then return false else error("inequality not satisfied; same notation as in the paper, dim(V*_A)="|toString(dimAmbientSV(l,a)+1)|", h="|toString(h)|", A="|toString(a)|", dimensions="|toString(l));
);
checkEffectivity = (l,d,a,b,h,quiet) -> (
   effectivity:=dimAmbientSV(l,b)+1 > h+dimSV(l,b);
   if ((not effectivity) and (not quiet)) then (if #l=!=1 then (<<"-- warning: applied non-effective criterion; same notation as in the paper, N(n,b)="<<dimAmbientSV(l,b)+1<<", dim(SV_b)="<<dimSV(l,b)<<", h="<<h<<", a="<<a<<", b="<<b<<", n="<<l<<endl;) else (<<"-- warning: applied non-effective criterion; same notation as in the paper, n="<<(l_0-1)<<", d="<<(d_0)<<", h="<<h<<", s="<<(a_0)<<", binom(n+d-s,n)="<<binomial(l_0-1+d_0-a_0,l_0-1)<<", h+n="<<(h+l_0-1)<<endl;)); 
   return effectivity;
);

-----------------------------------------------------------------
---------------- Documentation ----------------------------------
-----------------------------------------------------------------

beginDocumentation() 
document { 
    Key => Identifiability, 
    Headline => "Effective identifiability criteria for mixed symmetric tensors and polynomials",
    PARA{EM "Identifiability", " is a package implementing the algorithms on identifiability for tensors and homogeneous polynomials given in the paper: ",EM "Effective identifiability criteria for tensors and polynomials",", by A. Massarenti, M. Mella and G. Staglianò. More precisely, all those algorithms in the case of mixed symmetric tensors are implemented in the method ",TO "certifyIdentifiability", "."},
    PARA{"A mixed symmetric tensor of dimensions ",TEX///$l=\{l_1,l_2,\ldots\}$///," and multidegree ",TEX///$d=\{d_1,d_2,\ldots\}$///, " is interpreted as a multihomogeneous polynomial in ",TEX///$K[a_1,\ldots,a_{l_1},b_1,\ldots,b_{l_2},\ldots]$///," of multidegree ",TEX///$d$///, ". The method ",TO "switchNotation"," converts this polynomial to a multidimensional array of elements of ",TEX///$K$///,"; the method ",TO "multirandom", " makes random mixed symmetric tensors."}
}

undocumented{(certifyIdentifiability,RingElement),(certifyIdentifiability,RingElement,List,List,ZZ),(certifyIdentifiability,Matrix,List,List)}
document { 
    Key => {certifyIdentifiability,(certifyIdentifiability,RingElement,List,ZZ),(certifyIdentifiability,Matrix,List),(certifyIdentifiability,Matrix),(certifyIdentifiability,RingElement,ZZ)}, 
    Headline => "Certify specific identifiability of tensors and uniqueness of decompositions", 
    Usage => "certifyIdentifiability(F,h) 
              certifyIdentifiability D 
              certifyIdentifiability(F,l,h) 
              certifyIdentifiability(D,l)",
    Inputs => { "F" => RingElement => {"a mixed symmetric tensor, i.e. a multihomogeneous polynomial ",TEX///$F\in K[x_1,\ldots ,x_n]$///},
                "D" => Matrix => {"a row matrix of length ",TT"h"," of rank-one mixed symmetric tensors, hence ", TT"D"," is a multihomogeneous matrix over ",TEX///$K[x_1,\ldots ,x_n]$///},
                "l" => List => {"(optional) the dimensions of the tensor ",TT"F"," (resp. of ",TT"D","), i.e. a list of integers ",TEX///$l=(l_1,l_2,\ldots)$///," to indicate that ",TT"F"," (resp. ",TT"D",") is multihomogeneous with respect to the groups of variables: ",TEX///$(x_1,\ldots ,x_{l_1}),\ (x_{l_1+1},\ldots,x_{l_1+l_2}),\ldots$///,"; if not given, a ",EM"maximal multihomogeneity"," is used"},
                "h" => ZZ  
              }, 
    Outputs => { {"whether ",TT"F"," does not admit two different decompositions as sum of ",TT"h"," rank-one tensors (resp. the mixed symmetric tensor obtained as sum of the entries of ",TT"D"," is ",TT"h","-identifiable, i.e. the decomposition given by ",TT"D"," is unique)"} 
               },   
    PARA{"The algorithms implemented in this method are those given in the paper: ",EM "Effective identifiability criteria for tensors and polynomials",", by A. Massarenti, M. Mella and G. Staglianò. These algorithms certify the specific identifiability of mixed symmetric tensors. Note however that they are false negative algorithms: if the returned value is ",TT"false",", it means just that the constraints of the applied criteria are not satisfied."},
    EXAMPLE { 
          "-- a random mixed symmetric tensor of dimensions {2,4,3}, multidegree {4,1,5}, rank<=5, over ZZ/41
F = multirandom({2,4,3},{4,1,5},5,ZZ/41)",
          "time certifyIdentifiability(F,{2,4,3},5)",
          "time certifyIdentifiability(F,5)"
            },
    PARA{"If ",TT "F"," is a symmetric tensor, i.e. a homogeneous polynomial, say of degree ",TT"d"," in ",TT"n+1"," variables, and ", TT"h=wr(n,d)"," is the generic Waring rank, then such a general ","F"," is ",TT"h","-identifiable only in the following cases: ",TT"(n,d)=(1,2h-1)",", ",TT"h>1","; ",TT"(n,d)=(2,5)",", ",TT"h=7","; ",TT"(n,d)=(3,3)",", ",TT"h=5",". For these cases, the method uses the algorithm given in Theorem 3.8; so if it outputs ", TT"true", ", it means that ",TT"F"," is ",TT"h","-identifiable, i.e. ",TT "F"," can be expressed as a sum of ",TT"h"," powers of linear forms, and this expression is unique up to permutations and scaling of the linear forms. Just as above, if the returned value is ",TT"false",", it means that the constraints of the criterion are not satisfied."},
    EXAMPLE { 
          "-- a random 3-form of degree 5 and rank<=7
F = multirandom({3},{5},7)",
          "time certifyIdentifiability(F,7)",
          "-- a random 3-form of degree 5 and rank<=6
F = multirandom({3},{5},6)",
          "time certifyIdentifiability(F,7)",
          "time certifyIdentifiability(F,5)",
          "time certifyIdentifiability(F,6)"
            },
    PARA{"It is also possible to pass as input an explicit decomposition of the tensor ",TT"F", ", that is a multi-homogeneous row matrix of rank-one tensors. In this case, a further criterion is applied."},
    EXAMPLE { 
          "-- a random 1 x 7 matrix of rank 1 symmetric tensors of dimension 4 and degree 4
D = multirandom'({4},{4},7)",
          "time certifyIdentifiability D",
          "-- sum of the entries of D
F = sum flatten entries D",
          "time certifyIdentifiability(F,7)",
          "-- a random 1 x 5 matrix of rank 1 mixed symmetric tensors of dimensions {2,4,3} and degrees {4,1,5}
D = multirandom'({2,4,3},{4,1,5},5,ZZ/41)",
          "time certifyIdentifiability D"
            }
}

document { 
    Key => {multirandom,(multirandom,List,List,ZZ),(multirandom,List,List),(multirandom,List,List,ZZ,Ring),(multirandom,List,List,Ring)}, 
    Headline => "Make a random mixed symmetric tensor", 
    Usage => "multirandom(l,d,h,K) 
              multirandom(l,d,h) 
              multirandom(l,d,K) 
              multirandom(l,d)",
    Inputs => { "l" => List => {"the dimensions of the tensor"},
                "d" => List => {"the multidegree of the tensor"},
                "h" => ZZ  => {"(optional) the rank of the tensor"},
                "K" => Ring => {"the coefficient ring (optional with default value ",TO"QQ",")"}
              }, 
    Outputs => { {"a random mixed symmetric tensor (= multihomogeneous polynomial) of dimensions ",TT"l",", multidegree ",TT"d",", rank",TT"<h+1","."} 
               },   
    PARA{},
    EXAMPLE { 
          "time multirandom({2,3},{3,1},2)",
          "time multirandom({2},{3},ZZ/7)",
          "time multirandom({2,3,5,2},{3,6,1,2},5,ZZ/331)"
            },
    SeeAlso => {multirandom'}
}

document { 
    Key => {multirandom',(multirandom',List,List,ZZ),(multirandom',List,List),(multirandom',List,List,ZZ,Ring),(multirandom',List,List,Ring)}, 
    Headline => "Make a random row matrix of rank-one mixed symmetric tensors", 
    Usage => "multirandom'(l,d,h,K) 
              multirandom'(l,d,h) 
              multirandom'(l,d,K) 
              multirandom'(l,d)",
    Inputs => { "l" => List => {"the dimensions of the tensors"},
                "d" => List => {"the multidegree of the tensors"},
                "h" => ZZ  => {"the length of the row matrix"},
                "K" => Ring => {"the coefficient ring (optional with default value ",TO"QQ",")"}
              }, 
    Outputs => { {"a random row matrix of length ",TT"h"," of rank-one mixed symmetric tensors of dimensions ",TT"l"," and multidegree ",TT"d","."} 
               },
    PARA{"This method is quite similar to ", TO"multirandom", " except that it outputs ",TT"1 x h"," matrices of rank one tensors, instead of rank ",TT"h"," tensors; so we have \"",TT"multirandom(l,d,h,K) == sum flatten entries multirandom'(l,d,h,K)","\"."},
    EXAMPLE { 
          "time multirandom'({2,3},{3,1},2)",
          "time multirandom'({2,3,5,2},{3,6,1,2},5,ZZ/331)"
            }
}

undocumented {(findDecomposition,RingElement,ZZ,Nothing)} 
document { 
    Key => {findDecomposition,(findDecomposition,RingElement,ZZ)}, 
    Headline => "Decomposition as sum of h powers of linear forms of an h-identifiable polynomial (naive approach)", 
    Usage => "findDecomposition(F,h)",
    Inputs => { "F" => RingElement => {"an ",TEX///$h$///, "-identifiable homogeneous degree ",TEX///$d$///," polynomial, say ",TEX///$F=L_{1}^d+\cdots+L_{h}^d$///},
                "h" => ZZ   
              }, 
    Outputs => { {"the product of the linear forms ", TEX///$L_1\cdots L_h$///} 
               },  
    PARA{"The output is always a homogeneous polynomial of degree ",TEX///$h$///,", which splits into linear factors over the algebraic closure of the base field. If the input polynomial is not ",TEX///$h$///, "-identifiable, then an error message will be displayed."}, 
    EXAMPLE { 
          "ringP4 = ZZ/41[v,w,x,y,z]",
          "L = {random(1,ringP4),random(1,ringP4),random(1,ringP4)}",
          "F = L_0^5+L_1^5+L_2^5",
          "time P = findDecomposition(F,3)",
          "time factor P", 
          "ideal P == ideal product L"
            },
    PARA{},
    EXAMPLE {
           "ringP1 = ZZ/41[m,n]",
           "G = random(7,ringP1)",
           "time decompose ideal findDecomposition(G,4)"
            }
}

document { 
    Key => {switchNotation,(switchNotation,RingElement,List,List),(switchNotation,RingElement),(switchNotation,Array,List,List)}, 
    Headline => "Switch notation for mixed symmetric tensors between polynomial and multidimensional array", 
    Usage => "switchNotation(T,l,d)",
    Inputs => { "T" => {"a mixed symmetric tensor, i.e. either a multihomogeneous polynomial or an array of nested arrays of numbers"},
                "l" => List => {"a list of integers ",TEX///$l=(l_1,l_2,\ldots)$///," to indicate the dimensions of the mixed symmetrix tensor ",TT"T"},
                "d" => List => {"the multidegree ",TEX///$d=(d_1,d_2,\ldots)$///, " of the mixed symmetrix tensor ",TT"T"}
              }, 
    Outputs => { 
               "T" => {"the tensor ", TT"T", " written in the other notation"},
               "l" => List => {"the same ", TT"l", " as in input"},
               "d" => List => {"the same ", TT"d", " as in input"}
               },   
    Consequences => {TT "(T,l,d) == switchNotation switchNotation (T,l,d)"},
    EXAMPLE { 
          "F = multirandom({4,6,3,2},{2,1,3,2},ZZ/3331)",
          "time switchNotation switchNotation F === (F,{4,6,3,2},{2,1,3,2})",
          "first switchNotation F"
            }
}

-----------------------------------------------------------------
--------------------- Tests -------------------------------------
-----------------------------------------------------------------

TEST ///
P1=QQ[vars(0,1)]; P2=QQ[vars(0,1,2)]; P3=QQ[vars(0..3)]; 
assert certifyIdentifiability random(7,P1) 
assert certifyIdentifiability random(5,P2)
assert certifyIdentifiability random(3,P3)
G = (random(1,P2))^5 + (random(1,P2))^5 + (random(1,P2))^5
assert (certifyIdentifiability(G,3) and (not certifyIdentifiability(G,2)))
H = (random(1,P3))^3 + (random(1,P3))^3 + (random(1,P3))^3
assert (certifyIdentifiability(H,3) and (not certifyIdentifiability(H,2)))
assert (certifyIdentifiability(H,3) and (not certifyIdentifiability(H,4)))
///

TEST ///
assert certifyIdentifiability(multirandom({3},{5},6),6)
assert certifyIdentifiability(multirandom({4},{4},5),5)
assert certifyIdentifiability multirandom'({3},{5},6)
assert certifyIdentifiability multirandom'({4},{4},5)
assert certifyIdentifiability(multirandom({4},{3},4),4)
assert certifyIdentifiability(multirandom({3},{5},5,ZZ/331),5)
assert certifyIdentifiability(multirandom({4},{4},4,ZZ/331),4)
assert certifyIdentifiability(multirandom({4},{3},3,ZZ/331),3)
assert certifyIdentifiability(multirandom({3,2},{5,4},3,ZZ/331),3)
assert certifyIdentifiability(multirandom({4,2,3},{2,3,1},3),3)
assert certifyIdentifiability(multirandom({4,2,3},{2,3,1},3),{4,2,3},3)
assert certifyIdentifiability(multirandom({4,2,3},{2,3,1},3),{4,2,3},{1,2,0},3)
assert not certifyIdentifiability(multirandom({4,5},{2,3},3),2)
assert not certifyIdentifiability(multirandom({4,5},{3,3},3),4)
assert not certifyIdentifiability(multirandom({4},{4},7),7)
assert certifyIdentifiability multirandom'({4},{4},7) 
///

TEST ///
l={5,3,1}; d={1,2,4};
F=multirandom(l,d,2,QQ)
assert (switchNotation switchNotation switchNotation (F,l,d) == switchNotation (F,l,d))
assert (switchNotation switchNotation switchNotation F == switchNotation F)
assert (first switchNotation switchNotation(F,l,d) == F)
///

TEST///
use QQ[x,y,z]
assert(findDecomposition(x^6+y^6+z^6,3,) == ideal(y*z,x*z,x*y))
testFindDecomposition = (n,d,h) -> (
 x:=local x; R:=QQ[x_0..x_n];
 L:=for i to h-1 list (trim ideal random(1,R))_0;
 F:=sum for i to h-1 list (L_i)^d;
 P:=product L;
 toPr:=findDecomposition(F,h);
 ideal toPr == ideal P
);
assert testFindDecomposition(1,3,2);
assert testFindDecomposition(1,4,2);
assert testFindDecomposition(1,5,3);
assert testFindDecomposition(2,2,1);
assert testFindDecomposition(2,3,2);
assert testFindDecomposition(3,3,3);
///

 <<"--** Identifiability (v"|Identifiability.Options.Version|") loaded **--"<<endl;

end
     
