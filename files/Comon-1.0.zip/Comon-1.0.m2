newPackage(
   "Comon", Version => "1.0", Date => "September 11, 2018",
    Authors => {{Name => "A. Casarotti'", Email => "csrlxa@unife.it"}
		{Name => "A. Massarenti", Email=> "alexmassarenti@id.uff.br"}, 
                {Name => "M. Mella", Email=> "mll@unife.it"}},
    Headline => "Comon's conjecture",
    DebuggingMode => false, Reload => true)

export{"Comon"};

Comon = method(TypicalValue => String);
Comon (ZZ,ZZ,ZZ) := (n,d,h) -> (
k = floor((d+1)/2);
<< "Lowest rank for which the usual flattenings method does not work = " << binomial(n+floor(d/2),n) << "";
if (h < binomial(n+floor(d/2),n)) then return ("Comon's conjecture holds for the general degree "|toString(d)|" homogeneous polynomial in "|toString(n+1)|" variables of rank "|toString(h)|" by the usual flattenings method");
if (odd(d) == false) then return ("The method does not apply");
if (binomial(n+k,n) < 2*binomial(n+k-1,n)) then return ("The method does not apply");
if (2*h-1 > binomial(n+k,n)) then return ("The method does not apply, 2h-1 must be smaller than or equal to the number of order "|toString(k)|" partial derivatives --- For degree "|toString(d)|" homogeneous polynomial in "|toString(n+1)|" variables usual flattenings work for h strictly less than "|toString(binomial(n+k-1,n))|" so the interesting cases are for h varying between "|toString(binomial(n+k-1,n))|" and "|toString(floor((1/2)*(binomial(n+k,n)+1)))|"");
R = QQ[x_0..x_n];
v = basis(k,R);
S = R[a_{0,1}..a_{n,h}];
for i from 1 to h do L_i = sum(0..n,j->a_{j,i}*x_j);
F = sum(1..h,i->L_i^d);
for i from 0 to n do for j from 1 to h do F=sub(F,a_{i,j}=>random(QQ));
G = x_0*F;
D = diff(v ** transpose v,G);
P = submatrix(D,{0..2*h-2},{0..2*h-2});
A = det P;
if A==0 then return ("The method does not apply --- The determinant vanishes --- For degree "|toString(d)|" homogeneous polynomial in "|toString(n+1)|" variables usual flattenings work for h strictly less than "|toString(binomial(n+k-1,n))|" so the interesting cases are for h varying between "|toString(binomial(n+k-1,n))|" and "|toString(floor((1/2)*(binomial(n+k,n)+1)))|"");
return ("Comon's conjecture holds for the general degree "|toString(d)|" homogeneous polynomial in "|toString(n+1)|" variables of rank "|toString(h)|" --- For degree "|toString(d)|" homogeneous polynomial in "|toString(n+1)|" variables usual flattenings work for h strictly less than "|toString(binomial(n+k-1,n))|" so the interesting cases are for h varying between "|toString(binomial(n+k-1,n))|" and "|toString(floor((1/2)*(binomial(n+k,n)+1)))|"");
);

beginDocumentation()
multidoc ///
 Node
  Key
   Comon
  Headline
     Comon
  Description
   Text
    {\em Comon} 
  Caveat
    Comon
 Node
  Key
   (Comon,ZZ)
   Comon
  Headline
   Comon's conjecture
  Usage
   Comon(n,d,h)
  Inputs
   n,d,h:
  Outputs
  String:
  Description
   Text
    Examples.
   Example
    Cubics(3,3,4)
    Cubics
///

TEST ///
    assert ( Cubics(3,3,4) == "Comon's conjecture holds for the general degree 3 homogeneous polynomial in
     4 variables of rank 4 ----------------------- Remark: for degree 3
     homogeneous polynomial in 4 variables usual flattenings work for h strictly
     less than 4 so the interesting cases are for h varying between 4 and 5" )
///

TEST ///
    assert ( Cubics(3,3,5) == "The method does not apply ----------------------- Remark: for degree 3
      homogeneous polynomial in 4 variables usual flattenings work for h
      strictly less than 4 so the interesting cases are for h varying between 4
      and 5" )
///

end--

