// Input: an ideal I or an integer 
// Output: the F-faces indices of I.
//
// If I is an integer it returns 
// all the non-empty subsets of {1,..,I}.
// (uses Remark 3.1.1.11)

Ffaces := function(I)
 if Type(I) eq RngIntElt then
  return Subsets({1..I}) diff {{}};
 end if;
 B := Basis(I);
 R := Parent(I.1);
 n := Rank(R);
 faces := {};
 for S in Subsets({1..n}) diff {{}} do
  BS := [Evaluate(g,[(i in S) select R.i else 0 : i in [1..n]]) : g in B];
  if &*[R.i : i in S] notin Radical(Ideal(BS)) then
   Include(~faces,S);
  end if;
 end for;
 return faces;
end function;


// Input: grading matrix
// Output: effective cone

Eff := function(Q)
 n := Ncols(Q);
 K := ToricLattice(Nrows(Q));
 return Cone([K!Eltseq(r) : r in Rows(Transpose(Q))]);
end function;


// Input: grading matrix
// Output: moving cone

Mov := function(Q)
 n := Ncols(Q);
 K := ToricLattice(Nrows(Q));
 L := [K!Eltseq(r) : r in Rows(Transpose(Q))];
 return &meet([Cone([L[j] : j in Remove([1..#L],i)]) : i in [1..#L]]);
end function;


// Input: (F-faces,grading matrix)
// Output: orbit cones

OrbitCones := function(F,Q)
 n := Ncols(Q);
 K := ToricLattice(Nrows(Q));
 w := [K!Eltseq(r) : r in Rows(Transpose(Q))];
 if #F eq 0 then F := Subsets({1..n}) diff {{}}; end if;
 return {Cone([w[i] : i in S]) : S in F};
end function;

// Input: (orbit cones, a class)
// Output: GIT chamber

GitChamber := function(orb,w)
 K := Ambient(Random(orb));
 w := K!Eltseq(w);
 return &meet{C : C in orb | w in C};
end function;

// Input: (orbit cones, a class)
// Output: bunch of cones

BunchCones := function(orb,w)
 return {C : C in orb | w in C};
end function;


// Input: (bunch, class, class)
// Output: boolean
//
// It returns true if the two classes
// have the same stable base locus

SameSbl := function(bun,w1,w2)
 K := Ambient(Random(bun));
 w1 := K!Eltseq(w1);
 w2 := K!Eltseq(w2);
 return {C : C in bun | w1 in C} eq {C : C in bun | w2 in C};
end function;


// Input: orbit cones
// Output: GIT fan

GitFan := function(orb)
 Eff := Cone(&cat[Rays(C) : C in orb]);
 SH := {SupportingHyperplane(Eff,C) : C in Facets(Eff)};
 repeat
  W := Random(orb);
  K := Ambient(W);
  w := &+Rays(W);
  la := &meet{C : C in orb | w in C};
 until Dimension(la) eq Dimension(K);
 L := {la};
 F := {C : C in Facets(la) | SupportingHyperplane(la,C) notin SH};
 repeat
  ff := Random(F);
  la := Random([C : C in L | IsFace(C,ff)]); 
  H := K!SupportingHyperplane(la,ff);
  w := &+Rays(ff);
  if Dimension(Cone([w,w+H]) meet la) eq 0 
   then e := 1; 
   else e := -1;
  end if;
  n := 1;
  repeat
   u := w + e/10^n*H;
   n := n+1;
  until u in Eff;
  repeat
   lb := &meet{C : C in orb | u in C};
   u := w + e/10^n*H;
   n := n + 1;
  until Dimension(lb) eq Dimension(K) and lb meet la eq ff;
  L := L join {lb};
  Fb := {C : C in Facets(lb) | SupportingHyperplane(lb,C) notin SH};
  F := (F join Fb) diff (F meet Fb);
 until IsEmpty(F);
 return L;
end function;


// Input: (grading matrix, orbit cones, git fan)
// Output: list of triples 
// (git chamber, git chamber, git chamber)
//
// In each triple the first is the ample
// chamber and the remaining two are two
// git chambers which lie in the same sbl

FindTriples := function(Q,orb,gfan)
 K := Ambient(Random(gfan));
 mov := Cone([K!w : w in RGenerators(Mov(Q))]);
 triples := [];
 L := Setseq(gfan);
 M := [C : C in L | &and[w in mov : w in Rays(C)]];
 for C in M do
  bun := BunchCones(orb,&+Rays(C));
   ll := [[C,L[i],L[j]] : i,j in [1..#L] | 
              i lt j and L[i] ne C and L[j] ne C 
              and SameSbl(bun,&+Rays(L[i]),&+Rays(L[j]))];
  if #ll ne 0 then 
   Append(~triples,ll); 
  end if;
 end for;
 return triples;
end function;
