BsLib - a Magma library for GIT and Stable base chambers.

Current version: 1.0 (27.5.2018).

BsLib is a Magma library for computing GIT and Stable base chambers of varieties which admit a finitely generated Cox ring.

Copyright © 2018-2028: Antonio Laface, Alex Massarenti, Rick Richter.
All versions are distributed under the GNU General Public License.

Installation.

Copy the files "BsLib.m" and "Examples.txt" in one directory.
Run Magma from that directory.
Copy the text of one of the examples and paste it into the Magma prompt.
